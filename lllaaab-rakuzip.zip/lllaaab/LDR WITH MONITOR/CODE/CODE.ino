const int ldrPin = A0;   
const int ledPin = 13;   

const int threshold = 500; 

void setup() {
  Serial.begin(9600);
  
  pinMode(ledPin, OUTPUT);
  
  Serial.println("--- LDR Light Detection System Initialized ---");
}

void loop() {
  int ldrValue = analogRead(ldrPin);
  
  Serial.print("LDR Raw Value: ");
  Serial.print(ldrValue);
  
  if (ldrValue < threshold) {
    digitalWrite(ledPin, HIGH);
    Serial.println(" -> Status: DARK [LED ON]");
  } else {
    digitalWrite(ledPin, LOW);
    Serial.println(" -> Status: BRIGHT [LED OFF]");
  }
  
  delay(500);
}
