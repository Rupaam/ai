const int switch1Pin = 3;  
const int switch2Pin = 2;  
const int ledPin = 13;     

void setup() {
  pinMode(switch1Pin, INPUT);
  pinMode(switch2Pin, INPUT);
  
  pinMode(ledPin, OUTPUT);
}

void loop() {
  bool A = digitalRead(switch1Pin);
  bool B = digitalRead(switch2Pin);
  
 
  bool Y = A ^ B;
  
  digitalWrite(ledPin, Y);
  
  delay(50);
}
