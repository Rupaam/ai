
int segPins[7] = {13, 12, 11, 10, 9, 8, 7};


byte digits[10] = {
  0b00111111,  // 0
  0b00000110,  // 1
  0b01011011,  // 2
  0b01001111,  // 3
  0b01100110,  // 4
  0b01101101,  // 5
  0b01111101,  // 6
  0b00000111,  // 7
  0b01111111,  // 8
  0b01101111   // 9
};

void setup()
{
  for (int i = 0; i < 7; i++)
  {
    pinMode(segPins[i], OUTPUT);
  }
}

void displayDigit(int number)
{
  byte pattern = digits[number];

  for (int i = 0; i < 7; i++)
  {
    digitalWrite(segPins[i], bitRead(pattern, i));
  }
}

void loop()
{
  // Display 1
  displayDigit(1);
  delay(1000);

  // Display 5
  displayDigit(5);
  delay(1000);
}