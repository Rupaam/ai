void setup() {
  pinMode(10,OUTPUT);
  pinMode(9,OUTPUT);
  pinMode(8,OUTPUT);


}

void loop() {
  int red = 10;
  int yellow = 9;
  int green = 8;

  digitalWrite(green,LOW);
  digitalWrite(yellow,HIGH);
  delay(2000);

  digitalWrite(yellow,LOW);
  digitalWrite(red,HIGH);
  delay(2000);

  digitalWrite(yellow,HIGH);
  delay(2000);

  digitalWrite(yellow,LOW);
  digitalWrite(red,LOW);
  digitalWrite(green,HIGH);
  delay(2000);

}