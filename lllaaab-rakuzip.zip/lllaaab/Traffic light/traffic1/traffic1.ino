const int redLED = 13;
const int yellowLED = 12;
const int greenLED = 11;

void setup() {
  pinMode(redLED, OUTPUT);
  pinMode(yellowLED, OUTPUT);
  pinMode(greenLED, OUTPUT);
}

void loop() {
  digitalWrite(greenLED, HIGH);   
  digitalWrite(yellowLED, LOW);   
  digitalWrite(redLED, LOW);      
  delay(4000);                    

  digitalWrite(greenLED, LOW);    
  digitalWrite(yellowLED, HIGH);  
  digitalWrite(redLED, LOW);      
  delay(2000);                   

  digitalWrite(greenLED, LOW);    
  digitalWrite(yellowLED, LOW);   
  digitalWrite(redLED, HIGH);     
  delay(1000);                    
}