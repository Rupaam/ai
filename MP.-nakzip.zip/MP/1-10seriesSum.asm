MOV AX, 0
MOV CX, 10
MOV BX, 1

L1:
ADD AX, BX
INC BX
LOOP L1

; AX = 55

; Display 55
MOV DL, '5'
MOV AH, 02H
INT 21H

MOV DL, '5'
MOV AH, 02H
INT 21H

MOV AH, 4CH
INT 21H



