MOV AL, 26
MOV BL, 16

DIV BL

; AL = Quotient (1)
; AH = Remainder (10)

MOV CL, AH

; Display quotient
MOV DL, AL
ADD DL, 30H
MOV AH, 02H
INT 21H

; Display remainder as A
MOV DL, CL
ADD DL, 37H
MOV AH, 02H
INT 21H

MOV AH, 4CH
INT 21H


