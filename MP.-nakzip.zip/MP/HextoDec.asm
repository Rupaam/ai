MOV AL, 1AH
MOV BL, 10

DIV BL

; Quotient = 2, Remainder = 6

ADD AL, 30H
MOV CL, AH

MOV DL, AL
MOV AH, 02H
INT 21H

MOV DL, CL
ADD DL, 30H
MOV AH, 02H
INT 21H

MOV AH, 4CH
INT 21H

