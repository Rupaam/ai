int pin[] = {13, 12, 11, 10, 9, 7, 6};
byte code = 0b1110000;
void setup() {
 for (int i = 0; i < 7; i++) {
 pinMode(pin[i], OUTPUT);
 }
}
void loop() {
 for (int i = 0; i < 7; i++) {
 digitalWrite(pin[i], bitRead(code, 6 - i));
 }
}
