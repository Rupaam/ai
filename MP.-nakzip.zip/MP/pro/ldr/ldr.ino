const int ldrPin = A0;
const int ledPin = 13;

int ldrValue;

void setup() {
  pinMode(ledPin, OUTPUT);

  Serial.begin(9600);

  Serial.println("LDR Based LED Control");
  Serial.println("---------------------");
}

void loop() {

  ldrValue = analogRead(ldrPin);

  Serial.print("LDR Value: ");
  Serial.print(ldrValue);

  if (ldrValue > 500) {
    digitalWrite(ledPin, HIGH);
    Serial.println("  -> DARK, LED ON");
  }
  else {
    digitalWrite(ledPin, LOW);
    Serial.println("  -> BRIGHT, LED OFF");
  }

  delay(1000);
}
