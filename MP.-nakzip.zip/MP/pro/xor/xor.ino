int SWA = 13;
int SWB = 10;
int LED = 12;
void setup() {
 pinMode(SWA, INPUT);
 pinMode(SWB, INPUT);
 pinMode(LED, OUTPUT);
}
void loop() {
 int inputA = digitalRead(SWA);
 int inputB = digitalRead(SWB);
 if ((inputA == HIGH && inputB == LOW) ||
 (inputA == LOW && inputB == HIGH)) {
 digitalWrite(LED, HIGH);
 }
 else {
 digitalWrite(LED, LOW);
 }
}