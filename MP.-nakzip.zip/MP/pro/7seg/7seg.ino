int a = 13;
int b = 12;
int c = 11;
int d = 10;
int e = 9;
int f = 7;
int g = 6;
int segments[] = {a, b, c, d, e, f, g};

byte digit[10][7] = {
  {1,1,1,1,1,1,0}, // 0
  {0,1,1,0,0,0,0}, // 1
  {1,1,0,1,1,0,1}, // 2
  {1,1,1,1,0,0,1}, // 3
  {0,1,1,0,0,1,1}, // 4
  {1,0,1,1,0,1,1}, // 5
  {1,0,1,1,1,1,1}, // 6
  {1,1,1,0,0,0,0}, // 7
  {1,1,1,1,1,1,1}, // 8
  {1,1,1,1,0,1,1}  // 9
};
int myID[] = {2, 3, 1, 1, 1, 1, 0, 7};
void setup() {
  pinMode(a, OUTPUT);
  pinMode(b, OUTPUT);
  pinMode(c, OUTPUT);
  pinMode(d, OUTPUT);
  pinMode(e, OUTPUT);
  pinMode(f, OUTPUT);
  pinMode(g, OUTPUT);
}
void loop() {
  for (int i = 0; i < 8; i++) {
    for (int j = 0; j < 7; j++) {
      digitalWrite(segments[j], digit[myID[i]][j]);
    }
    delay(1000);
  }
  delay(2000);
}
