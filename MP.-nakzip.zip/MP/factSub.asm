; Calculate 5!
MOV AX, 1
MOV BX, 5
MOV CX, 5

L1:
MUL BX
DEC BX
LOOP L1

MOV SI, AX       ; Store 5! = 120

; Calculate 3!
MOV AX, 1
MOV BX, 3
MOV CX, 3

L2:
MUL BX
DEC BX
LOOP L2

; Subtract factorials
MOV BX, AX       ; Store 3! = 6
MOV AX, SI
SUB AX, BX       ; 120 - 6 = 114

; Display 114
MOV DL, '1'
MOV AH, 02H
INT 21H

MOV DL, '1'
MOV AH, 02H
INT 21H

MOV DL, '4'
MOV AH, 02H
INT 21H

MOV AH, 4CH
INT 21H


