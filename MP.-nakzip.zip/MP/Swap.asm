MOV AX, 5
MOV BX, 3

; Swap two numbers
XCHG AX, BX

; Display first number
ADD AX, 30H
MOV DL, AL
MOV AH, 02H
INT 21H

; Display second number
MOV DL, BL
ADD DL, 30H
MOV AH, 02H
INT 21H

MOV AH, 4CH
INT 21H



