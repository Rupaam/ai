MOV AH, 01H
INT 21H
SUB AL, 30H
MOV BL, AL

MOV AH, 01H
INT 21H
SUB AL, 30H
ADD BL, AL

MOV AH, 01H
INT 21H
SUB AL, 30H
ADD BL, AL

MOV AL, BL
MOV AH, 00H
MOV BL, 03H
DIV BL

; Average is now in AL, so AX contains the average
ADD AL, 30H
MOV DL, AL
MOV AH, 02H
INT 21H



