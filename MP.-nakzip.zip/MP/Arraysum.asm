
.MODEL SMALL
.STACK 100H
.DATA
ARR DB 1,2,3,4,5
SUM DB 0

.CODE
MAIN PROC
    MOV AX,@DATA
    MOV DS,AX

    LEA SI,ARR
    MOV CX,5
    MOV AL,0

L1:
    ADD AL,[SI]
    INC SI
    LOOP L1

    MOV SUM,AL

    ; Convert decimal number into digits
    MOV AH,0
    MOV BL,10
    DIV BL

    ; Display tens digit
    MOV BH,AH
    ADD AL,30H
    MOV DL,AL
    MOV AH,02H
    INT 21H

    ; Display units digit
    MOV DL,BH
    ADD DL,30H
    MOV AH,02H
    INT 21H

    MOV AH,4CH
    INT 21H
MAIN ENDP
END MAIN
