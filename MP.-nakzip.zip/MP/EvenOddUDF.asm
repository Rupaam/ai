.MODEL SMALL
.STACK 100H

.CODE
MAIN PROC

    MOV AX, 8
    CALL CHECK

    MOV AH, 4CH
    INT 21H

MAIN ENDP

CHECK PROC

    MOV BL, 2
    DIV BL

    CMP AH, 0
    JE EVEN

    MOV DL, 'O'
    MOV AH, 02H
    INT 21H
    JMP EXIT

EVEN:
    MOV DL, 'E'
    MOV AH, 02H
    INT 21H

EXIT:
    RET

CHECK ENDP

END MAIN


