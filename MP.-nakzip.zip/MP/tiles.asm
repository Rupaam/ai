MOV AX, 20
MOV BX, 20
MUL BX

MOV BX, 4
DIV BX

MOV CX, AX

; Display result (100)

MOV DL, '1'
MOV AH, 02H
INT 21H

MOV DL, '0'
MOV AH, 02H
INT 21H

MOV DL, '0'
MOV AH, 02H
INT 21H

MOV AH, 4CH
INT 21H



