MOV AL, 1010B
MOV BL, 2

; Convert binary to decimal
MOV AH, 00H
MOV CL, 10
DIV CL

; Display tens digit
ADD AL, 30H
MOV DL, AL
MOV AH, 02H
INT 21H

; Display units digit
MOV DL, AH
ADD DL, 30H
MOV AH, 02H
INT 21H

MOV AH, 4CH
INT 21H

